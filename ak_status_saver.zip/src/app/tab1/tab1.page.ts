
import { Component, OnInit } from '@angular/core';
// import { ImagePicker } from '@ionic-native/image-picker/ngx';
import { ActionSheetController, Platform } from '@ionic/angular';
import {
  MediaCapture,
  MediaFile,
  CaptureError
} from '@ionic-native/media-capture/ngx';
import { File, FileEntry } from '@ionic-native/File/ngx';
import { Media, MediaObject } from '@ionic-native/media/ngx';
import { StreamingMedia } from '@ionic-native/streaming-media/ngx';
import { PhotoViewer } from '@ionic-native/photo-viewer/ngx';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
const MEDIA_FOLDER_NAME = '.Statuses';
@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  files = [];
  allVideos: any;
  allPhotos: any;
 
  constructor(
    // private imagePicker: ImagePicker,
    private mediaCapture: MediaCapture,
    private file: File,
    private media: Media,
    private streamingMedia: StreamingMedia,
    private photoViewer: PhotoViewer,
    private actionSheetController: ActionSheetController,
    private plt: Platform,
    private androidPermissions: AndroidPermissions
  ) {}
 
  ngOnInit() {
    this.plt.ready().then(() => {
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE).then(
        result => console.log('Has permission?',result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE)
      );

      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE).then(
        result => console.log('Has permission?',result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE)
      );
      
      this.androidPermissions.requestPermissions([
        this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE, 
        this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE
      ]);

    
      this.loadFiles()
      let path = this.file.externalRootDirectory+'Android/media/com.whatsapp/Whatsapp/Media/';
      console.log(this.file.applicationStorageDirectory )
      this.file.checkDir(path, MEDIA_FOLDER_NAME).then(
        () => {
          // alert('exist')
          this.loadFiles();
        },
        err => {
          console.log(err)
          // this.file.createDir(path, MEDIA_FOLDER_NAME, false);
        }
      );
    });
  }
 
  loadFiles() { 
    // this.file.externalApplicationStorageDirectory
    this.file.listDir(this.file.externalRootDirectory+'Android/media/com.whatsapp/Whatsapp/Media/', '.Statuses').then(
      res => {
        console.log(res)
        this.files = res; 
        const mediaMap = res.map(async (media) => {
          let extension = media.name.split('.').pop()
          
          if (extension === 'mp4') {
            this.allVideos.push(media)
          } else if(extension === 'jpg') {
            this.allPhotos.push(media)
            
          }
        })
        console.log(this.allVideos)
      },
      err => console.log('error loading files: ', err)
    );
  }

}

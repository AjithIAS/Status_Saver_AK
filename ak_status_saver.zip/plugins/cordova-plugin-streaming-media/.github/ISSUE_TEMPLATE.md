<!--
Note that leaving sections blank will make it difficult for us to troubleshoot and we may have to close the issue.
-->

**What version of Streaming-Meda-Cordova-Plugin are you using?**

**What version of Cordova are you using?**

**What devices are affected?**

**Please describe the issue in detail, with relevant code samples**

**What did you expect to happen?**

**What actually happened?**
